import logging
import os
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger("agroshift.config")


def _parse_origins(raw: str):
    if not raw:
        return ["http://localhost:5173", "http://localhost:3000"]
    return [origin.strip() for origin in raw.split(",") if origin.strip()]


class Settings:
    PORT: int = int(os.getenv("PORT", 8000))
    HOST: str = os.getenv("HOST", "0.0.0.0")
    GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")
    COPERNICUS_CLIENT_ID: str = os.getenv("COPERNICUS_CLIENT_ID", "")
    COPERNICUS_CLIENT_SECRET: str = os.getenv("COPERNICUS_CLIENT_SECRET", "")
    OPENWEATHER_API_KEY: str = os.getenv("OPENWEATHER_API_KEY", "")
    ALLOWED_ORIGINS: list = _parse_origins(os.getenv("ALLOWED_ORIGINS", ""))


settings = Settings()

