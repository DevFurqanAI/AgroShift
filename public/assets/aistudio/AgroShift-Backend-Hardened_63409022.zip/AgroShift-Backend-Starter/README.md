# AgroShift — Backend Starter (TerraWise reuse)

This starter intentionally contains **NO TerraWise frontend**, no UI designs, no copied UI components and no installed node packages. It preserves the field-analysis backend as the basis for a new global, farmer-first NASA Space Apps 2026 application.

## Already implemented
- FastAPI app and request/response schemas for `POST /api/v1/analyze` (field health analysis).
- Copernicus Sentinel-2 NDVI and NDMI field statistics; credentials required. **These are ESA/Copernicus observations, not NASA data.**
- Open-Meteo weather observations and optional OpenWeatherMap fallback.
- Existing English/Urdu AI-explanation fallbacks, optional Groq integration; plan to replace or isolate for Gemini.
- Polygon GeoJSON support and center-coordinate fallback.
- **NEW:** `GET /api/v1/climate/history?latitude=30.2&longitude=71.5&start_year=2020&end_year=2024` reads actual NASA POWER historical monthly temperature and precipitation (mm/day), with explicit attribution and missing-data handling. Requires network access.

## NOT implemented (must build for the challenge)
- Multi-season crop rotation decision engine, crop database, local crop calendars, soil-health modeling, farmer priorities, suitability scoring, farmer authentication, persistence, Gemini integration, translations beyond English/Urdu, modern frontend.
- No climate forecasts, no agricultural guarantees. Do not invent values or present illustrative crop scores as real.

## Run locally
```bash
cd backend
python -m venv .venv
# activate the virtual environment on your operating system
pip install -r requirements.txt
cp .env.example .env  # Windows: copy .env.example .env
uvicorn app.main:app --reload
pytest -q
```
API docs: http://localhost:8000/docs. `GET /` is a health check. Cross-origin requests are restricted to configured `ALLOWED_ORIGINS`; set the exact hosted frontend origin in production. Satellite analysis requires external API connectivity and credentials. The NASA POWER endpoint needs internet access but no key.

## Google AI Studio handoff
This is **not a complete Google AI Studio deployable web app**. Google AI Studio Build typically generates a React/TypeScript app and a Node.js runtime; a Python FastAPI server may need separate hosting. Upload or paste these files as project context, or import the repository where supported. Tell AI Studio to **create an entirely new frontend** while preserving and integrating this Python backend. Never rewrite mature satellite/weather logic unless needed for compatibility or tests. Keep secrets server-side.

## Scientific notes
- `cloud_cover_percent` in the inherited field endpoint is an approximate percentage of unusable sampled pixels, **not** a validated direct cloud-cover measurement. A future refactor should rename and improve this.
- Legacy NDVI, NDMI, heat and rainfall labels are heuristic, not crop-specific suitability predictions.
- NASA POWER precipitation rate in the new endpoint is mm/day, not monthly total.
- Test mocks do not establish that any external provider is currently responding.

## Attribution
Source: TerraWise Pakistan backend uploaded by the user; refactored for AgroShift. External APIs: Copernicus Data Space, Open-Meteo, OpenWeatherMap (optional), NASA POWER.

## AI Studio import limitations and development sequence
This ZIP contains **Python source**, not a runnable Google AI Studio React app. If AI Studio cannot import ZIP archives as projects, extract the ZIP and give its files as context (or import through a supported GitHub workflow). Do not ask the builder to silently convert all Python code to TypeScript. Host the FastAPI backend independently and build a new React frontend that consumes the API.

Suggested implementation order: (1) new farmer interface, (2) server connectivity and environment setup, (3) NASA POWER live-data checks, (4) rotation engine, (5) farm persistence, (6) AI explanations. The crop rotation engine and full scientific validation are **not included** in this archive.

**Legacy naming:** `cloud_cover_percent` is retained for API compatibility but denotes approximate unusable sampled pixels; do not display it as measured cloud cover. Legacy temperature/rainfall labels and NDVI/NDMI thresholds are qualitative heuristics and must not directly drive global crop suitability.

**Dependencies:** Groq is intentionally optional: `pip install groq` only if using the inherited optional Groq client. No real credentials are included.


## Resilience and calculation notes (November 2026 review)

- `/api/v1/analyze` returns a low-confidence response with null measurements when upstream observations are unavailable; it does **not** manufacture values.
- `/api/v1/climate/history` returns `data_available: false`, `monthly: []`, and a message when the NASA service is unreachable or data cannot be parsed. The frontend must respect this flag rather than charting empty results as zero.
- NASA monthly `PRECTOTCORR` is expressed as **mm/day**. `estimated_monthly_precipitation_mm` multiplies this rate by calendar days (including leap years). This is an estimate based on NASA's monthly aggregate, not an observed daily series.
- NDVI and NDMI are dimensionless band ratios. Bucketing thresholds and the heat/rainfall flags are generic heuristics, **not crop-specific diagnoses**. `possible_water_stress` is only a heuristic.
- OpenWeatherMap 3-hour forecast fallback is partial-day aggregation, **not** observed full-day rainfall. No estimate should be marketed as a measured daily total.
- Sentinel-2 valid-pixel coverage is not identical to meteorological cloud cover. The `cloud_cover_percent` field is a legacy naming approximation; a future refactor should rename it to `invalid_pixel_percent` and update the API client and confidence logic.
- The NASA POWER historical data service does not replace measured soil nutrients, regional crop calendars, or the unimplemented crop rotation engine.
- Network responses are **mocked in tests**; live external NASA, Copernicus, Open-Meteo, and OpenWeatherMap availability has not been verified.
- Run `cd backend && python -m pytest -q` and `python -m uvicorn app.main:app --reload` after extracting the archive.
